-- =============================================================================
-- Saedni — Migration 002: Disable Row Level Security
-- Target: Supabase (PostgreSQL 15+)
-- Idempotent: safe to run multiple times
-- Why: The app uses its own session-based auth, not Supabase Auth.
--      RLS is enabled by default on Supabase and will block all queries
--      from the Express API unless disabled here.
-- =============================================================================

ALTER TABLE public.users               DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.requests            DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_notifications DISABLE ROW LEVEL SECURITY;

-- Verify RLS is off
SELECT
    relname   AS table_name,
    relrowsecurity AS rls_enabled
FROM pg_class
WHERE relname IN ('users', 'requests', 'admin_notifications')
  AND relkind = 'r'
ORDER BY relname;

-- Expected output: rls_enabled = false for all 3 tables
