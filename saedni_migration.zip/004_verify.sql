-- =============================================================================
-- Saedni — Migration 004: Verification
-- Run after 001 + 002 + 003 to confirm migration success
-- =============================================================================

-- 1. Row counts — expected: users=4, requests=1, admin_notifications=7
SELECT 'users'               AS table_name, count(*) AS row_count FROM public.users
UNION ALL
SELECT 'requests',                          count(*) FROM public.requests
UNION ALL
SELECT 'admin_notifications',               count(*) FROM public.admin_notifications
ORDER BY table_name;

-- 2. RLS status — expected: rls_enabled=false for all 3
SELECT relname AS table_name, relrowsecurity AS rls_enabled
FROM pg_class
WHERE relname IN ('users', 'requests', 'admin_notifications')
  AND relkind = 'r'
ORDER BY relname;

-- 3. Sequence state — expected: last_value=26 / 60 / 7
SELECT sequencename, last_value
FROM pg_sequences
WHERE sequencename IN (
    'users_id_seq',
    'requests_id_seq',
    'admin_notifications_id_seq'
)
ORDER BY sequencename;

-- 4. Indexes — expected: 3 PKs + 1 unique on phone + 1 partial unique on auth_token
SELECT
    indexname,
    tablename,
    indexdef
FROM pg_indexes
WHERE schemaname = 'public'
  AND tablename IN ('users', 'requests', 'admin_notifications')
ORDER BY tablename, indexname;

-- 5. Admin accounts exist and are admin type
SELECT id, name, phone, user_type, is_verified, is_blocked
FROM public.users
WHERE user_type = 'admin'
ORDER BY id;

-- 6. Next INSERT id test — new rows should auto-increment correctly
-- (do NOT run in production unless you want test rows; review only)
-- Expected: users_id_seq nextval = 27, requests_id_seq nextval = 61
SELECT
    nextval('public.users_id_seq')               AS next_user_id,
    nextval('public.requests_id_seq')            AS next_request_id,
    nextval('public.admin_notifications_id_seq') AS next_notification_id;
-- NOTE: running the above advances the sequences by 1 each.
-- After confirming, reset if needed:
-- SELECT setval('public.users_id_seq', 26, true);
-- SELECT setval('public.requests_id_seq', 60, true);
-- SELECT setval('public.admin_notifications_id_seq', 7, true);
