-- =============================================================================
-- Saedni — Migration 003: Data Import
-- Target: Supabase (PostgreSQL 15+)
-- Idempotent: ON CONFLICT DO NOTHING — safe to run multiple times
-- Note: password_hash values are base64-encoded hashes, NOT plaintext
--       passwords. Keep this file secure and do not commit to public repos.
-- Source: Replit PostgreSQL — exported 2026-06-20
-- =============================================================================

-- ---------------------------------------------------------------------------
-- admin_notifications (7 rows)
-- ---------------------------------------------------------------------------
INSERT INTO public.admin_notifications (id, type, title, user_id, user_name, phone, user_type, is_read, created_at)
VALUES
    (1, 'otp_request', 'طلب رمز تحقق جديد', 22, 'أحتاج مساعدة', '1',   'customer', false, '2026-05-30 15:47:34.668917+00'),
    (2, 'otp_request', 'طلب رمز تحقق جديد', 24, 'عميل',          '1',   'customer', false, '2026-05-30 15:55:58.335242+00'),
    (3, 'otp_request', 'طلب رمز تحقق جديد', 25, 'مساعد',         '2',   'customer', false, '2026-05-30 15:57:25.301624+00'),
    (4, 'otp_request', 'طلب رمز تحقق جديد', 25, 'مساعد',         '2',   'customer', false, '2026-05-30 15:57:45.087307+00'),
    (5, 'otp_request', 'طلب رمز تحقق جديد', 25, 'مساعد',         '2',   'customer', false, '2026-05-30 15:57:59.841794+00'),
    (6, 'otp_request', 'طلب رمز تحقق جديد', 26, 'مساعد',         '2',   'helper',   false, '2026-05-30 15:58:31.615699+00'),
    (7, 'otp_request', 'طلب رمز تحقق جديد', 26, 'مساعد',         '2',   'helper',   true,  '2026-06-04 14:43:31.970776+00')
ON CONFLICT (id) DO NOTHING;

-- ---------------------------------------------------------------------------
-- requests (1 row)
-- ---------------------------------------------------------------------------
INSERT INTO public.requests
    (id, customer_id, helper_id, category, details, area, time_type,
     scheduled_date_time, offered_amount, status, created_at, help_completed, completed_at)
VALUES
    (60, 24, NULL, 'labor', 'احتاج تمصيرة الحين', 'مسقط', 'scheduled',
     '2029-05-30T16:56:00.000Z', 2, 'available', '2026-05-30 15:56:55.63506+00', NULL, NULL)
ON CONFLICT (id) DO NOTHING;

-- ---------------------------------------------------------------------------
-- users (4 rows)
-- password_hash: base64(password + salt) — functional, matches existing app auth
-- ---------------------------------------------------------------------------
INSERT INTO public.users
    (id, name, phone, password_hash, user_type, area, rating,
     is_verified, is_blocked, created_at, last_login,
     otp_code, otp_created_at, helper_interests, preferred_areas,
     auth_token, roles, expo_push_token)
VALUES
    -- Test helper (empty password — OTP-only account)
    (26, 'مساعد',      '2',          '',
     'helper',   NULL,    NULL,  true,  false,
     '2026-05-30 15:58:31.611818+00', '2026-05-30 15:59:16.398+00',
     NULL, NULL, '[]', '[]', NULL, NULL, NULL),

    -- Primary admin account
    (7,  'سليمان',     '98584898',   '2Y3YudmF2LTZh9ip2LTZiTEwc2FpZG5pX3NhbHRfMjAyNA==',
     'admin',    'مسقط', NULL,  true,  false,
     '2026-05-28 13:42:50.950719+00', '2026-06-09 16:06:26.933+00',
     NULL, NULL, NULL, NULL, NULL, NULL, NULL),

    -- Seed admin account
    (6,  'مدير النظام', '96891000000', 'MTIzNDU2c2FpZG5pX3NhbHRfMjAyNA==',
     'admin',    'مسقط', NULL,  true,  false,
     '2026-05-28 13:32:40.722119+00', '2026-05-28 18:31:24.074+00',
     NULL, NULL, NULL, NULL, NULL, NULL, NULL),

    -- Test customer (empty password — OTP-only account)
    (24, 'عميل',       '1',          '',
     'customer', NULL,   NULL,  true,  false,
     '2026-05-30 15:55:58.320542+00', '2026-05-30 15:56:25.486+00',
     NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ON CONFLICT (id) DO NOTHING;

-- ---------------------------------------------------------------------------
-- IMPORTANT: After the above insert, run this UPDATE to restore the real
-- password hashes for admin accounts. Get the hash values from the Replit
-- production database using: SELECT id, phone, password_hash FROM users;
-- ---------------------------------------------------------------------------
-- UPDATE public.users SET password_hash = '<hash_from_replit_db>' WHERE id = 7;
-- UPDATE public.users SET password_hash = '<hash_from_replit_db>' WHERE id = 6;

-- ---------------------------------------------------------------------------
-- Reset sequences to next available IDs
-- ---------------------------------------------------------------------------
SELECT pg_catalog.setval('public.admin_notifications_id_seq', 7,  true);
SELECT pg_catalog.setval('public.requests_id_seq',            60, true);
SELECT pg_catalog.setval('public.users_id_seq',               26, true);
