-- =============================================================================
-- Saedni — Migration 001: Schema
-- Target: Supabase (PostgreSQL 15+)
-- Idempotent: safe to run multiple times
-- =============================================================================

-- ---------------------------------------------------------------------------
-- TABLE: users
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.users (
    id               integer      NOT NULL,
    name             text         NOT NULL,
    phone            text         NOT NULL,
    password_hash    text         NOT NULL,
    user_type        text         NOT NULL DEFAULT 'customer',
    area             text,
    rating           real,
    is_verified      boolean      NOT NULL DEFAULT false,
    is_blocked       boolean      NOT NULL DEFAULT false,
    created_at       timestamptz  NOT NULL DEFAULT now(),
    last_login       timestamptz,
    otp_code         text,
    otp_created_at   timestamptz,
    helper_interests text,
    preferred_areas  text,
    auth_token       text,
    roles            text,
    expo_push_token  text
);

CREATE SEQUENCE IF NOT EXISTS public.users_id_seq
    AS integer START WITH 1 INCREMENT BY 1
    NO MINVALUE NO MAXVALUE CACHE 1;

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;

ALTER TABLE public.users
    ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);

DO $$ BEGIN
    ALTER TABLE ONLY public.users ADD CONSTRAINT users_pkey PRIMARY KEY (id);
EXCEPTION WHEN duplicate_table THEN NULL; END $$;

DO $$ BEGIN
    ALTER TABLE ONLY public.users ADD CONSTRAINT users_phone_unique UNIQUE (phone);
EXCEPTION WHEN duplicate_table THEN NULL; END $$;

CREATE UNIQUE INDEX IF NOT EXISTS users_auth_token_unique
    ON public.users USING btree (auth_token)
    WHERE (auth_token IS NOT NULL);

-- ---------------------------------------------------------------------------
-- TABLE: requests
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.requests (
    id                   integer      NOT NULL,
    customer_id          integer      NOT NULL,
    helper_id            integer,
    category             text         NOT NULL,
    details              text         NOT NULL,
    area                 text         NOT NULL,
    time_type            text         NOT NULL DEFAULT 'now',
    scheduled_date_time  text,
    offered_amount       real         NOT NULL,
    status               text         NOT NULL DEFAULT 'available',
    created_at           timestamptz  NOT NULL DEFAULT now(),
    help_completed       boolean,
    completed_at         timestamptz
);

CREATE SEQUENCE IF NOT EXISTS public.requests_id_seq
    AS integer START WITH 1 INCREMENT BY 1
    NO MINVALUE NO MAXVALUE CACHE 1;

ALTER SEQUENCE public.requests_id_seq OWNED BY public.requests.id;

ALTER TABLE public.requests
    ALTER COLUMN id SET DEFAULT nextval('public.requests_id_seq'::regclass);

DO $$ BEGIN
    ALTER TABLE ONLY public.requests ADD CONSTRAINT requests_pkey PRIMARY KEY (id);
EXCEPTION WHEN duplicate_table THEN NULL; END $$;

-- ---------------------------------------------------------------------------
-- TABLE: admin_notifications
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.admin_notifications (
    id         integer      NOT NULL,
    type       text         NOT NULL DEFAULT 'otp_request',
    title      text         NOT NULL,
    user_id    integer,
    user_name  text,
    phone      text         NOT NULL,
    user_type  text,
    is_read    boolean      NOT NULL DEFAULT false,
    created_at timestamptz  NOT NULL DEFAULT now()
);

CREATE SEQUENCE IF NOT EXISTS public.admin_notifications_id_seq
    AS integer START WITH 1 INCREMENT BY 1
    NO MINVALUE NO MAXVALUE CACHE 1;

ALTER SEQUENCE public.admin_notifications_id_seq OWNED BY public.admin_notifications.id;

ALTER TABLE public.admin_notifications
    ALTER COLUMN id SET DEFAULT nextval('public.admin_notifications_id_seq'::regclass);

DO $$ BEGIN
    ALTER TABLE ONLY public.admin_notifications
        ADD CONSTRAINT admin_notifications_pkey PRIMARY KEY (id);
EXCEPTION WHEN duplicate_table THEN NULL; END $$;

-- ---------------------------------------------------------------------------
-- Verify
-- ---------------------------------------------------------------------------
SELECT
    table_name,
    (SELECT count(*) FROM information_schema.columns c
     WHERE c.table_name = t.table_name AND c.table_schema = 'public') AS column_count
FROM information_schema.tables t
WHERE table_schema = 'public'
  AND table_name IN ('users', 'requests', 'admin_notifications')
ORDER BY table_name;
