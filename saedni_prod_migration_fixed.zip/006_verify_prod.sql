-- ساعدني: Post-migration verification (production dataset)
  -- Expected: users=22, requests=18, admin_notifications=90

  SELECT 'users'               AS tbl, COUNT(*) AS n FROM public.users
  UNION ALL
  SELECT 'requests',                    COUNT(*)       FROM public.requests
  UNION ALL
  SELECT 'admin_notifications',         COUNT(*)       FROM public.admin_notifications;

  -- Sequences (last_value should equal max IDs: users=44, requests=85, notifications=90)
  SELECT 'users_id_seq'               AS seq, last_value FROM users_id_seq
  UNION ALL
  SELECT 'requests_id_seq',                  last_value FROM requests_id_seq
  UNION ALL
  SELECT 'admin_notifications_id_seq',       last_value FROM admin_notifications_id_seq;

  -- Confirm ghost users are gone (should return 0 rows)
  SELECT id, phone FROM public.users WHERE id IN (6, 24, 26);

  -- Confirm production phone conflicts resolved (should each return exactly 1 row)
  SELECT id, phone, user_type FROM public.users WHERE phone IN ('1','2') ORDER BY phone;

  -- Helpers with push tokens
  SELECT id, name, user_type, is_verified, expo_push_token IS NOT NULL AS has_push
  FROM public.users WHERE user_type='helper' ORDER BY id;

  -- Request status breakdown
  SELECT status, COUNT(*) FROM public.requests GROUP BY status ORDER BY status;
  