-- ساعدني: Post-migration verification
  -- Run this after 005_prod_data.sql to confirm all rows imported correctly.

  -- Expected: users=22, requests=18, admin_notifications=90
  SELECT 'users'               AS tbl, COUNT(*) AS n FROM public.users
  UNION ALL
  SELECT 'requests',                    COUNT(*)       FROM public.requests
  UNION ALL
  SELECT 'admin_notifications',         COUNT(*)       FROM public.admin_notifications;

  -- Sequence values (should be ≥ max IDs)
  SELECT 'users_id_seq'               AS seq, last_value FROM users_id_seq
  UNION ALL
  SELECT 'requests_id_seq',                  last_value FROM requests_id_seq
  UNION ALL
  SELECT 'admin_notifications_id_seq',       last_value FROM admin_notifications_id_seq;

  -- Spot-check: confirm verified helpers exist
  SELECT id, name, user_type, is_verified, expo_push_token IS NOT NULL AS has_push_token
  FROM public.users WHERE user_type = 'helper' ORDER BY id;

  -- Spot-check: request status breakdown
  SELECT status, COUNT(*) FROM public.requests GROUP BY status ORDER BY status;
  